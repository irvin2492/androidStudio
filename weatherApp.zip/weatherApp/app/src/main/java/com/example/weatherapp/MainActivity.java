package com.example.weatherapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class MainActivity extends AppCompatActivity {

    TextView weather;
    EditText cityInp;
    public class weatherTask extends AsyncTask<String,Void,String>{
        @Override
        protected String doInBackground(String... strings) {
            String result = "";
            try {
                URL url = new URL(strings[0]);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                InputStream in = urlConnection.getInputStream();
                InputStreamReader input = new InputStreamReader(in);
                int data = input.read();

                while (data != -1) {
                    char ch = (char) data;
                    result += ch;
                    data = input.read();
                }
                return result;
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(new Runnable()
                {
                    public void run()
                    {
                        Toast.makeText(getApplicationContext(), "unable to get weather ", Toast.LENGTH_SHORT).show();
                    }//importatnt to remember
                    
                });
                return "Error";

            }
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONObject res = new JSONObject(s);
                String weatherInfo = res.getString("weather");

                JSONArray arr = new JSONArray(weatherInfo);
                String message="";
                for(int i =0; i<arr.length();i++){
                    JSONObject jPart = arr.getJSONObject(i);

                    String main=jPart.getString("main");
                    String desc = jPart.getString("description");

                    if(!main.equals("")&& !desc.equals("")){
                        message= main + ": " + desc+ "\r\n";
                    }
                    else{
                        Toast.makeText(getApplicationContext(), "unable to get weather ", Toast.LENGTH_SHORT).show();
                    }
                    if(!message.equals("")){
                        weather.setText(message);

                    }
                }


            }catch(Exception e){
                Toast.makeText(getApplicationContext(), "unable to get weather ", Toast.LENGTH_SHORT).show();
                e.printStackTrace();

            }
        }
    }

    public void getWeather(View v) {
        String result = "";

        weatherTask task = new weatherTask();
        try {
            String encodedCity= URLEncoder.encode(cityInp.getText().toString(),"UTF-8");
            result = task.execute("https://openweathermap.org/data/2.5/weather?q="+encodedCity+"&appid=439d4b804bc8187953eb36d2a8c26a02").get();
            //Log.i("Result",result);
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "unable to get weather ", Toast.LENGTH_SHORT).show();

            e.printStackTrace();
        }
        InputMethodManager mg = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        mg.hideSoftInputFromWindow(cityInp.getWindowToken(),0);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        weather = findViewById(R.id.weather);
        cityInp = findViewById(R.id.cityInp);
    }
}
